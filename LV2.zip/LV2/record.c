#include "r_macro.h"  /* System macro and standard type definition */
#include"timer.h"
#include"lcd.h"
#include "record.h"
#include "Display_record.h"

extern time_t time;
extern int record_time;
extern time_t time_record[20];
int line;
void  record(void){
	int i;
	time_record[record_time].minute=time.minute;
	time_record[record_time].second=time.second;
	time_record[record_time].centisecond=time.centisecond;
	line =record_time%6 +2;
	if (record_time>=6){
	for (i=0; i<=5;i++){
	Display_record(time_record[record_time+i-5],i+2,record_time+i-5);
        }
	}else 
	Display_record(time_record[record_time],line,record_time);
	}
	
