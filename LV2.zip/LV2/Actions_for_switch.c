#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"
#include "lcd.h"    /* LCD driver interface */
#include "Actions_for_switch.h"
#include "Port.h"
#include "record.h"
#include "scroll.h"


#define PAUSING 1
#define RUNNING 2
#define SCROLL_UP 3
#define SCROLL_DOWN 4
#define NO_RECORD 5

extern int action;
extern int Sw;
extern time_change;
extern int record_time;
extern int move;

/******************************************************************************
* Function Name: Actions_for_switchh
* Description  : Action for each switch
* Arguments    : none
* Return Value : none
******************************************************************************/
void Actions_for_switch(void) {
	    
	    switch (Sw){
		    case 1:/* Actions if Switch 1 are pressed */
	                   { 
			   if (record_time==0){
		           //Display_NoRecord();
			    }else {
		           if ((record_time-move)>6){
			   move=move+1;
			   scroll_up(move);
			   }else {
			   //Display_FirstRecord();
			   }
			   }
			   }
			   break;
	    
	            case 2: /* Actions if Switch 2 are pressed */
		           { 
			   if (record_time==0){
			   //Display_NoRecord();
			   }else if (move>0){
			   move=move-1;
			   scroll_down(move);
			   }else {
			   //Display_LastRecord();
			   }
	                   }
			   break;
			   
                    case 3: /* Actions if Switch 3 are pressed */
		          {
		           if (action == PAUSING){
		           action = RUNNING;
			   time_change=1;
			   EI();
                           timer_start();
		          }
		           else if (action == RUNNING){
			   if (record_time<=19){
			   move=0;
			   record();
			   record_time=record_time+1;
			   }else {
			   }
		          }
			  }
			   break;
		   case 4: /* Actions if Switch 1&2 are pressed */
		          {
		           if (action == RUNNING){
		           action = PAUSING;
			   time_change=0;
			   EI();
                           timer_stop();
		          }else if (action == PAUSING){
			   time_change=0;
			   EI();
			   timer_reset();
			  }
			  }
			  break;
		   
		   default : break;

	
	    }
}
