#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"    /* Timer driver interface */
#include "lcd.h"      /* LCD driver interface */ 
char * string_shown_on_lcd1[8];
extern time_t time;
extern time_change;
extern volatile int G_elapsedTime;
 void Display_record(time_t time,int line, int record_time){
	int a;
	a=0;
	if (time.second<=9){
	sprintf(string_shown_on_lcd1, "#%d:%d%d:%d%d:%d",record_time+1,a,time.minute,a,time.second,time.centisecond);
	DisplayLCD(line*8, string_shown_on_lcd1);
	}else if ( time.second>9&&time.minute<=9){
	        sprintf(string_shown_on_lcd1, "#%d:%d%d:%d:%d",record_time+1,a,time.minute,time.second,time.centisecond);
	        DisplayLCD(line*8, string_shown_on_lcd1);
	        
		}else { sprintf(string_shown_on_lcd1, "#%d:%d:%d:%d",record_time+1,time.minute,time.second,time.centisecond);
	                DisplayLCD(line*8, string_shown_on_lcd1);
		}
	
	
}
	